/**
 * Block YouTube Shorts - Content Script
 *
 * Defaults are baked in so the extension works out of the box.
 * Admins can override or extend every list via managed storage policy
 * in Google Admin Console (Policy for extensions JSON).
 */

// ── Defaults ────────────────────────────────────────────────────────
// These are used when no managed policy is pushed, or as a fallback
// if managed storage is unavailable.

const DEFAULT_CSS_SELECTORS = [
  // Shorts overlay / badge on thumbnails
  '[is-shorts]',
  'ytd-reel-shelf-renderer',
  'ytd-reel-item-renderer',
  'ytd-shorts',

  // Individual video renderers linking to /shorts/
  'ytd-grid-video-renderer:has(a[href^="/shorts/"])',
  'ytd-grid-video-renderer:has([overlay-style="SHORTS"])',
  'ytd-rich-item-renderer:has(a[href^="/shorts/"])',
  'ytd-rich-item-renderer:has([overlay-style="SHORTS"])',
  'ytd-video-renderer:has(a[href^="/shorts/"])',
  'ytd-video-renderer:has([overlay-style="SHORTS"])',
  'ytd-compact-video-renderer:has(a[href^="/shorts/"])',
  'ytd-compact-video-renderer:has([overlay-style="SHORTS"])',
  'ytd-trending-video-renderer:has([href^="/shorts/"])',

  // Shorts sections / shelves on homepage and channel pages
  'ytd-rich-section-renderer:has(ytd-reel-shelf-renderer)',
  'ytd-rich-section-renderer:has(ytd-reel-item-renderer)',

  // Sidebar navigation links
  'ytd-guide-entry-renderer:has(a[title="Shorts"])',
  'ytd-guide-entry-renderer:has(a[aria-label*="Shorts" i])',
  'ytd-mini-guide-entry-renderer:has(a[title="Shorts"])',
  'ytd-mini-guide-entry-renderer:has(a[aria-label*="Shorts" i])',
];

const DEFAULT_TEXT_FILTERS = [
  // Channel page Shorts tab (old style)
  { selector: 'tp-yt-paper-tab', text: 'Shorts' },
  // Channel page Shorts tab (new style)
  { selector: 'yt-tab-shape', text: 'Shorts' },
  // Sidebar entry (fallback for missing title/aria-label)
  { selector: 'ytd-guide-entry-renderer', text: 'Shorts' },
  { selector: 'ytd-mini-guide-entry-renderer', text: 'Shorts' },
  // Shorts shelf headers
  { selector: 'ytd-rich-section-renderer', childSelector: '#title-text', text: 'Shorts' },
  { selector: 'ytd-rich-section-renderer', childSelector: '#rich-shelf-header', text: 'Shorts' },
  { selector: 'ytd-item-section-renderer', childSelector: '#title', text: 'Shorts' },
  // Search chips
  { selector: 'yt-chip-cloud-chip-renderer', text: 'Shorts' },
];

const DEFAULT_REDIRECT_SHORTS = true;

// ── State ───────────────────────────────────────────────────────────

let cssSelectors = DEFAULT_CSS_SELECTORS;
let textFilters = DEFAULT_TEXT_FILTERS;
let redirectShorts = DEFAULT_REDIRECT_SHORTS;
let styleElement = null;

// ── CSS injection ───────────────────────────────────────────────────

function injectCSS() {
  if (styleElement) {
    styleElement.remove();
  }
  if (cssSelectors.length === 0) return;

  styleElement = document.createElement('style');
  styleElement.id = 'block-yt-shorts-css';
  styleElement.textContent = cssSelectors
    .map(sel => `${sel} { display: none !important; }`)
    .join('\n');

  (document.head || document.documentElement).appendChild(styleElement);
}

// ── Text-based filtering ────────────────────────────────────────────

function applyTextFilters() {
  for (const filter of textFilters) {
    try {
      const elements = document.querySelectorAll(filter.selector);
      for (const el of elements) {
        if (el.dataset.shortsHidden === '1') continue;

        const target = filter.childSelector
          ? el.querySelector(filter.childSelector)
          : el;

        if (!target) continue;

        const content = target.textContent.trim();
        if (content && new RegExp(`(^|\\s)${escapeRegex(filter.text)}(\\s|$)`, 'i').test(content)) {
          el.style.setProperty('display', 'none', 'important');
          el.dataset.shortsHidden = '1';
        }
      }
    } catch (e) {
      // Skip invalid selectors silently
    }
  }
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ── /shorts/ redirect ───────────────────────────────────────────────

function checkRedirect() {
  if (!redirectShorts) return;
  if (location.pathname.startsWith('/shorts/')) {
    // Redirect to the same video as a regular watch page
    const videoId = location.pathname.split('/shorts/')[1]?.split(/[/?#]/)[0];
    if (videoId) {
      window.location.replace(`https://www.youtube.com/watch?v=${videoId}`);
    } else {
      window.location.replace('https://www.youtube.com');
    }
  }
}

// ── SPA navigation handling ─────────────────────────────────────────
// YouTube is a single-page app; catch client-side navigation.

function hookNavigation() {
  const origPush = history.pushState;
  const origReplace = history.replaceState;

  history.pushState = function () {
    origPush.apply(this, arguments);
    onNavigate();
  };
  history.replaceState = function () {
    origReplace.apply(this, arguments);
    onNavigate();
  };
  window.addEventListener('popstate', onNavigate);
  // YouTube fires yt-navigate-finish on SPA transitions
  window.addEventListener('yt-navigate-finish', onNavigate);
}

function onNavigate() {
  checkRedirect();
  applyTextFilters();
}

// ── MutationObserver ────────────────────────────────────────────────
// Re-apply text filters as YouTube lazily renders content.

function startObserver() {
  const observer = new MutationObserver(() => {
    applyTextFilters();
  });
  const target = document.body || document.documentElement;
  observer.observe(target, { childList: true, subtree: true });
}

// ── Load config from managed storage ────────────────────────────────

function loadManagedConfig() {
  return new Promise((resolve) => {
    try {
      chrome.storage.managed.get(
        ['cssSelectors', 'textFilters', 'redirectShorts'],
        (result) => {
          if (chrome.runtime.lastError) {
            // No managed policy — use defaults
            resolve();
            return;
          }
          if (Array.isArray(result.cssSelectors) && result.cssSelectors.length > 0) {
            cssSelectors = result.cssSelectors;
          }
          if (Array.isArray(result.textFilters) && result.textFilters.length > 0) {
            textFilters = result.textFilters;
          }
          if (typeof result.redirectShorts === 'boolean') {
            redirectShorts = result.redirectShorts;
          }
          resolve();
        }
      );
    } catch (e) {
      // storage.managed may throw if unavailable
      resolve();
    }
  });
}

// ── Bootstrap ───────────────────────────────────────────────────────

async function init() {
  await loadManagedConfig();
  checkRedirect();
  injectCSS();

  if (document.body) {
    applyTextFilters();
    startObserver();
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      applyTextFilters();
      startObserver();
    });
  }

  hookNavigation();
}

init();
