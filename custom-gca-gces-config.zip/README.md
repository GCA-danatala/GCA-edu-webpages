# Block YouTube Shorts — Chrome Extension

Managed MV3 extension that hides YouTube Shorts UI elements and redirects
`/shorts/` URLs to the normal video player. Works out of the box with
sensible defaults, and every setting can be overridden via managed storage
policy in Google Admin Console.

## Files

- `manifest.json` — MV3 manifest
- `managed_storage.json` — Managed storage schema (defines the policy fields)
- `content.js` — Content script injected on youtube.com

## What it blocks (defaults)

- Shorts shelves on homepage, search, and channel pages
- Shorts sidebar / mini-guide navigation links
- Shorts tabs on channel pages
- Individual video thumbnails linking to /shorts/
- "Shorts" search filter chips
- Direct navigation to /shorts/* URLs (redirects to /watch?v=)

## Deployment

### 1. Host the extension

**Option A — Chrome Web Store (unlisted):**
Zip the three files, upload as an unlisted extension, note the extension ID.

**Option B — Self-hosted:**
1. Zip the three files
2. Host on an internal web server with an update manifest XML
3. Use the extension ID + update URL in Admin Console

### 2. Force-install via Admin Console

Go to **Admin Console → Devices → Chrome → Apps & extensions → Managed Guest Sessions**

Add the extension by ID and set to **Force install**.

### 3. Push policy (optional — only if you want to override defaults)

In the **Policy for extensions** field, paste your JSON. The extension works
with no policy at all; the defaults are baked in. Only push a policy if you
need to customise the selectors or disable the redirect.

#### Example: Override everything

```json
{
  "cssSelectors": {
    "Value": [
      "[is-shorts]",
      "ytd-reel-shelf-renderer",
      "ytd-reel-item-renderer",
      "ytd-shorts",
      "ytd-grid-video-renderer:has(a[href^=\"/shorts/\"])",
      "ytd-rich-item-renderer:has(a[href^=\"/shorts/\"])",
      "ytd-video-renderer:has(a[href^=\"/shorts/\"])",
      "ytd-compact-video-renderer:has(a[href^=\"/shorts/\"])",
      "ytd-guide-entry-renderer:has(a[title=\"Shorts\"])",
      "ytd-mini-guide-entry-renderer:has(a[title=\"Shorts\"])",
      "ytd-rich-section-renderer:has(ytd-reel-shelf-renderer)"
    ]
  },
  "textFilters": {
    "Value": [
      { "selector": "tp-yt-paper-tab", "text": "Shorts" },
      { "selector": "yt-tab-shape", "text": "Shorts" },
      { "selector": "ytd-rich-section-renderer", "childSelector": "#title-text", "text": "Shorts" },
      { "selector": "yt-chip-cloud-chip-renderer", "text": "Shorts" }
    ]
  },
  "redirectShorts": {
    "Value": true
  }
}
```

#### Example: Disable the /shorts/ redirect only

```json
{
  "redirectShorts": {
    "Value": false
  }
}
```

Any field you omit keeps its baked-in default.

## Updating filters

To update filters without republishing the extension:

1. Edit the policy JSON in Admin Console
2. Save — the new selectors take effect next time a managed guest session opens YouTube

The extension reads managed storage at page load, so changes apply on
next session start (no extension update needed).
